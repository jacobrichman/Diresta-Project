-- MySQL dump 10.13  Distrib 5.5.42, for Linux (x86_64)
--
-- Host: localhost    Database: Day
-- ------------------------------------------------------
-- Server version	5.5.42-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `Day`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `Day` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `Day`;

--
-- Table structure for table `Entries`
--

DROP TABLE IF EXISTS `Entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Entries` (
  `User_ID` varchar(40) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Entry_ID` varchar(40) NOT NULL,
  `Year` int(4) NOT NULL,
  `Month` int(2) NOT NULL,
  `Day` int(2) NOT NULL,
  `Picture_Location` varchar(250) NOT NULL,
  `Address` varchar(75) NOT NULL,
  `Location_1` varchar(25) NOT NULL,
  `Location_2` varchar(25) NOT NULL,
  `Content` text NOT NULL,
  PRIMARY KEY (`Entry_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Entries`
--

LOCK TABLES `Entries` WRITE;
/*!40000 ALTER TABLE `Entries` DISABLE KEYS */;
INSERT INTO `Entries` VALUES ('1','jarichman43','1234567',2014,7,14,'https://d1d2zx9bjhpmma.cloudfront.net/api/media/1200/1200/43537/F5FD3AA0F0B2474C85B9A0CFF2E5B46A.jpg','Uziya+11+Street','Jerusalem','Israel','- I missed the bus today but it was fine because I too the next one and I was still the second person at work today\r\n- everyone was tired today at work after watching the world cup last night\r\n- I did my posts and then we had the company meeting, Zvi is starting to get a bit annoying because he never remember anything I do and he%1s always very busy, Victor is much better but I guess that%1s what their job titles represent\r\n- I did the posts with Ari%1s approval and I spent the day finding fee codes and reformatting them and alphabetizing and finding duplicates and matching names that have different codes, at the end of the day I started looking up definitions for that about 20 air codes I found as opposed to 1200 water quotes that I found\r\n- I uploaded the video to YouTube and added in the annotations and description, I put it in the blog post and wrote an email to Eytan\r\n- towards the end of the day I got a bit bored, but it%1s not like I don%1t have things to do, I was just tired\r\n- for lunch they got us all pizza which was pretty good for Israel and as expected it came with the chilly spice and cardboard\r\n- I came home and had a snack and then Dad and I left for tel aviv, I slept most of the way and Dad told me about his day and then he had a call\r\n- when we arrive at the Container which is a warehouse in the Jaffa port, I went in and dad parked and stayed on the call and watched the sun set on the Mediterranean, I checked in and since I didn%1t know what a networking event was I just sat at a table and ate the food that they offered, it was all free, I watched the sun set while relaxing 10 feet from boats and then right before they actually started Dad came and we went in, it was at some artsy and hippy sort of place and the event was run by the Respect Network who had just traveled all around the world and this was their last stop, they teamed up with Emmett Global a Israeli company and this event was to promote internet security opposed to companies like Facebook and Google who take your information when you surf, the speakers didn%1t speak so well,t he only good person was the MC who had a great 5 minute slideshow and he was very energetic it was all within one hour so it was chick chock and most of it was very interesting, I didn%1t understand half of it but I signed up fro an account afterwards with a username of %2google%2, after the speeches they had more food and Saul Singer the co-author of Start-Up Nation had just spoke and I got a picture with him as you can see in todays picture and he gave out free books and he singed one for me, I also got a signed book'),('1','jacobrichman','3456789',2014,7,28,'https://d1d2zx9bjhpmma.cloudfront.net/api/media/1200/1200/43537/F5FD3AA0F0B2474C85B9A0CFF2E5B46A.jpg','Uziya+11+Street','Jerusalem','Israel','- I missed the bus today but it was fine because I too the next one and I was still the second person at work today\r\n- everyone was tired today at work after watching the world cup last night\r\n- I did my posts and then we had the company meeting, Zvi is starting to get a bit annoying because he never remember anything I do and he’s always very busy, Victor is much better but I guess that’s what their job titles represent\r\n- I did the posts with Ari’s approval and I spent the day finding fee codes and reformatting them and alphabetizing and finding duplicates and matching names that have different codes, at the end of the day I started looking up definitions for that about 20 air codes I found as opposed to 1200 water quotes that I found\r\n- I uploaded the video to YouTube and added in the annotations and description, I put it in the blog post and wrote an email to Eytan\r\n- towards the end of the day I got a bit bored, but it’s not like I don’t have things to do, I was just tired\r\n- for lunch they got us all pizza which was pretty good for Israel and as expected it came with the chilly spice and cardboard\r\n- I came home and had a snack and then Dad and I left for tel aviv, I slept most of the way and Dad told me about his day and then he had a call\r\n- when we arrive at the Container which is a warehouse in the Jaffa port, I went in and dad parked and stayed on the call and watched the sun set on the Mediterranean, I checked in and since I didn’t know what a networking event was I just sat at a table and ate the food that they offered, it was all free, I watched the sun set while relaxing 10 feet from boats and then right before they actually started Dad came and we went in, it was at some artsy and hippy sort of place and the event was run by the Respect Network who had just traveled all around the world and this was their last stop, they teamed up with Emmett Global a Israeli company and this event was to promote internet security opposed to companies like Facebook and Google who take your information when you surf, the speakers didn’t speak so well,t he only good person was the MC who had a great 5 minute slideshow and he was very energetic it was all within one hour so it was chick chock and most of it was very interesting, I didn’t understand half of it but I signed up fro an account afterwards with a username of “google”, after the speeches they had more food and Saul Singer the co-author of Start-Up Nation had just spoke and I got a picture with him as you can see in todays picture and he gave out free books and he singed one for me, I also got a signed book '),('1','jarichman43','7654321',2014,7,31,'https://d1d2zx9bjhpmma.cloudfront.net/api/media/1200/1200/43537/F5FD3AA0F0B2474C85B9A0CFF2E5B46A.jpg','10+Berkley+Road','Framingham','MA','- I missed the bus today but it was fine because I too the next one and I was still the second person at work today\r\n- everyone was tired today at work after watching the world cup last night\r\n- I did my posts and then we had the company meeting, Zvi is starting to get a bit annoying because he never remember anything I do and he’s always very busy, Victor is much better but I guess that’s what their job titles represent\r\n- I did the posts with Ari’s approval and I spent the day finding fee codes and reformatting them and alphabetizing and finding duplicates and matching names that have different codes, at the end of the day I started looking up definitions for that about 20 air codes I found as opposed to 1200 water quotes that I found\r\n- I uploaded the video to YouTube and added in the annotations and description, I put it in the blog post and wrote an email to Eytan\r\n- towards the end of the day I got a bit bored, but it’s not like I don’t have things to do, I was just tired\r\n- for lunch they got us all pizza which was pretty good for Israel and as expected it came with the chilly spice and cardboard\r\n- I came home and had a snack and then Dad and I left for tel aviv, I slept most of the way and Dad told me about his day and then he had a call\r\n- when we arrive at the Container which is a warehouse in the Jaffa port, I went in and dad parked and stayed on the call and watched the sun set on the Mediterranean, I checked in and since I didn’t know what a networking event was I just sat at a table and ate the food that they offered, it was all free, I watched the sun set while relaxing 10 feet from boats and then right before they actually started Dad came and we went in, it was at some artsy and hippy sort of place and the event was run by the Respect Network who had just traveled all around the world and this was their last stop, they teamed up with Emmett Global a Israeli company and this event was to promote internet security opposed to companies like Facebook and Google who take your information when you surf, the speakers didn’t speak so well,t he only good person was the MC who had a great 5 minute slideshow and he was very energetic it was all within one hour so it was chick chock and most of it was very interesting, I didn’t understand half of it but I signed up fro an account afterwards with a username of “google”, after the speeches they had more food and Saul Singer the co-author of Start-Up Nation had just spoke and I got a picture with him as you can see in todays picture and he gave out free books and he singed one for me, I also got a signed book ');
/*!40000 ALTER TABLE `Entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `UserID` int(25) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Username` varchar(65) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `EmailAddress` varchar(255) NOT NULL,
  `Code` varchar(32) NOT NULL,
  `Active` tinyint(1) NOT NULL,
  `Date` varchar(32) NOT NULL,
  `LoginSession` varchar(250) NOT NULL,
  `ResetPasswordCode` varchar(250) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Jacob','Richman','jarichman43','d9b23ebbf9b431d009a20df52e515db5','jarichman43@gmail.com','70efdf2ec9b086079795c442636b55fb',1,'June 23rd, 2014','526c326e2839c7ee4698e02edc739938','45c48cce2e2d7fbdea1afc51c7c6ad26'),(2,'Maya ','Richman','mayabess','d10dae8a49795b4c062da383242a65dd','mayabess@gmail.com','37693cfc748049e45d87b8c7d8b9aacd',1,'June 24th, 2014','c6cbff53802b7a9cbf4d48bfa0f7f607','3416a75f4cea9109507cacd8e2f2aefc');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'Day'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-29 19:52:40
